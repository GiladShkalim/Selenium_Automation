# Application configuration settings for the IntelliShop app
