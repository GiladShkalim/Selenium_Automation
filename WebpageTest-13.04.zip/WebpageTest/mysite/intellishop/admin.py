# Configuration for the Django admin interface to manage models
