# Database models defining the data structure for IntelliShop
